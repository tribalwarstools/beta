// ==UserScript==
// @name         Auto Etiquetador Tribal Wars
// @namespace    https://tribalwarstools.github.io/
// @version      1.2
// @description  Auto etiqueta ataques e recarrega página somente se não houver etiquetas pendentes, com contador no painel TW-style
// @author       Você
// @match        https://*.tribalwars.com.br/game.php*screen=overview_villages&*mode=incomings*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    if (!window.autoEtiquetaCarregado) {
        window.autoEtiquetaCarregado = true;

        function loadScript() {
            if (typeof $ !== 'undefined' && $.getScript) {
                $.getScript('https://tribalwarstools.github.io/twscripts/autoEtiqueta.js');
            } else {
                // Se jQuery não carregou ainda, tenta novamente em 100ms
                setTimeout(loadScript, 100);
            }
        }

        loadScript();
    }

})();
