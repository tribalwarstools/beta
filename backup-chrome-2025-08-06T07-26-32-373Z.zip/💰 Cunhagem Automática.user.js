// ==UserScript==
// @name         💰 Cunhagem Automática
// @namespace    https://tribalwars.com.br/
// @version      1.8.6
// @description  Cunha moedas com botão único de iniciar/parar, painel TW arrastável. Funciona na visão geral e aldeia, sem parar se faltar recursos.
// @author       Giovani
// @match        *://*.tribalwars.com.br/game.php?*screen=snob*
// @icon         https://dsen.innogamescdn.com/asset/28ad7792/graphic/buildings/snob.png
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    if (!window.cunhagemCarregado) {
        window.cunhagemCarregado = true;

        function loadScript() {
            if (typeof $ !== 'undefined' && $.getScript) {
                $.getScript('https://tribalwarstools.github.io/twscripts/cunhagem.js');
            } else {
                // Se jQuery não carregou ainda, tenta novamente em 100ms
                setTimeout(loadScript, 100);
            }
        }

        loadScript();
    }

})();
