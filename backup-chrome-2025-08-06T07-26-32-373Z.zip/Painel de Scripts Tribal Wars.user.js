// ==UserScript==
// @name         Painel de Scripts Tribal Wars
// @namespace    https://tribalwarstools.github.io/
// @version      1.0
// @description  Painel flutuante com atalhos para scripts do Tribal Wars
// @author       Giovani
// @match        https://*.tribalwars.com.br/game.php*
// @icon         https://dsbr.innogamescdn.com/asset/d2c9c906/graphic/buildings/garage.webp
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    if (!window.PainelCarregado) {
        window.PainelCarregado = true;

        function loadScript() {
            if (typeof $ !== 'undefined' && $.getScript) {
                $.getScript('https://tribalwarstools.github.io/twscripts/PainelScripts.js');
            } else {
                // Se jQuery não carregou ainda, tenta novamente em 100ms
                setTimeout(loadScript, 100);
            }
        }

        loadScript();
    }

})();
